package utils

class PhotoUtils {
}